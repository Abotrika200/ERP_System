<?php

namespace Modules\Assets\Entities;

use Illuminate\Database\Eloquent\Model;

class businessprofit extends Model
{
    protected $guarded = ['id'];
    protected $table='business_profits';
}
