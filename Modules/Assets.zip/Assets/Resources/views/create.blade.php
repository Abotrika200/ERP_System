@extends('layouts.app')
@section('title','إضافة الشركاء')

@section('content')
    @include('Assets::layouts.nav')

@endsection