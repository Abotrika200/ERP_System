@extends('layouts.app')
@section('title','الموقف المالي')

@section('content')
    @include('Assets::layouts.nav')
@endsection