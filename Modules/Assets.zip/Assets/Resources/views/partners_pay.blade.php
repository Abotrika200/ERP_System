@extends('layouts.app')
@section('title','سجل مدفوعات الشركاء')

@section('content')
    @include('Assets::layouts.nav')
@endsection