@extends('layouts.app')
@section('title',' الشركاء')

@section('content')
    @include('Assets::layouts.nav')
@endsection