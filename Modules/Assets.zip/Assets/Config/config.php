<?php

return [
    'name' => 'Assets',
    'module_version' => "1.8",
    'pid' => 4
];
