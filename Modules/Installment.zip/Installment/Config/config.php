<?php

return [
    'name' => 'Installment',
    'module_version' => "2.9",
    'pid' => 6

];
