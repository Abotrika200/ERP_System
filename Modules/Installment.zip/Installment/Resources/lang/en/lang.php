<?php
return [
    'installment'=>'installment',
    'supplier'=>'installment supplier',
    'customer'=>'installment customer',
    'installment_plan'=>'installment system',
    'creat'=>'Add New',
    'edit'=>'Edit Data',
    'delete'=>'Delete Data',
    'update'=>'Update Data',
];
